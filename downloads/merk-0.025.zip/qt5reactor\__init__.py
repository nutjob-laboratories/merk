from qt5reactor.core import install, QtReactor

import qt5reactor._version
__version__ = qt5reactor._version.get_versions()['version']
