
# Load in resource file
globals()["merk.resources.resources"] = __import__("merk.resources.resources")

MDI_BACKGROUND = ":/gui-background.png"

BUNDLED_FONT = ":/font-FiraMono-Regular.ttf"
OTHER_BUNDLED_FONTS = [
	":/font-FiraMono-Medium.ttf",
	":/font-FiraMono-Bold.ttf",
]
BUNDLED_FONT_SIZE = 9
