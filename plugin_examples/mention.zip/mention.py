from merk import Plugin

class MentionNotify(Plugin):

    NAME = "Mention Notification"
    AUTHOR = "Dan Hetrick"
    VERSION = "1.0"
    SOURCE = "https://github.com/nutjob-laboratories/merk"

    def message(self,**args):
        window = args["window"]
        channel = args["channel"]
        user = args["user"]
        message = args["message"]
        client = args["client"]

        if window!=None:
            if not window.active():
                if window.type()=="channel" or window.type()=="private":
                    window.title(window.name()+" - Unread messages")

    def activate(self,**args):
        window = args["window"]
        window.title('')
