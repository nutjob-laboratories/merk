from merk import Plugin
import os

class Notepad(Plugin):

    NAME = "Notepad"
    AUTHOR = "Dan Hetrick"
    VERSION = "1.0"
    SOURCE = "https://github.com/nutjob-laboratories/merk"

    def init(self):
        self.macro("note","note.merk","/note MESSAGE","Writes a note")

    def pause(self):
        self.unmacro("note")

    def unpause(self):
        self.macro("note","note.merk","/note MESSAGE","Writes a note")

    def uninstall(self):
        self.unmacro("note")
        script = self.find("note","merk")
        if script!=None: os.remove(script)

    def save(self,window,arguments):
        if len(arguments)>0:
            if arguments[0]!="none":
                console = self.console()
                console.print(" ".join(arguments))
