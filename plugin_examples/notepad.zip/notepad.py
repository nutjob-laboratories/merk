from merk import Plugin

class Notepad(Plugin):

    NAME = "Notepad"
    AUTHOR = "Dan Hetrick"
    VERSION = "1.0"
    SOURCE = "https://github.com/nutjob-laboratories/merk"

    def init(self):
        self.macro("note","note.merk","/note MESSAGE","Writes a note")

    def save(self,window,arguments):
        if len(arguments)>0:
            if arguments[0]!="none":
                console = self.console()
                console.print(" ".join(arguments))