from merk import Plugin
from PyQt5.QtCore import *
import time

class DelayThread(QThread):
    threadEnd = pyqtSignal()
    def __init__(self,wait):
        super(DelayThread, self).__init__()
        self.time = wait

    def run(self):
        time.sleep(self.time)
        self.threadEnd.emit()

class SlowHello(Plugin):

    NAME = "Slow Hello"
    AUTHOR = "Dan Hetrick"
    VERSION = "1.0"
    SOURCE = "https://github.com/nutjob-laboratories/merk"

    def say_hello(self):
        if self.window.type()=="channel" or self.window.type()=="private":
            self.window.say("Hello!")
        else:
            self.window.print("Hello!")

    def slow_hello(self,window,arguments):
        self.window = window
        self.thread = DelayThread(10)
        self.thread.threadEnd.connect(self.say_hello)
        self.thread.start()
