from merk import Plugin
import random, os

class TroutMacro(Plugin):
	NAME = "Trout Macro"
	AUTHOR = "Dan Hetrick"
	VERSION = "1.0"
	SOURCE = "https://github.com/nutjob-laboratories/merk"

	def init(self):
		self.macro("trout","trout.merk","/trout TARGET","Slaps someone with a trout")

	def unload(self):
		self.unmacro("trout")

	def pause(self):
		self.unmacro("trout")

	def unpause(self):
		self.macro("trout","trout.merk","/trout TARGET","Slaps someone with a trout")

	def uninstall(self):
		self.unmacro("trout")
		script = self.find("trout","merk")
		if script!=None: os.remove(script)