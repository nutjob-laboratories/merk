from merk import Plugin
import urllib.request
import urllib.error
import os

class MyIPPlugin(Plugin):

    NAME = "My IP"
    AUTHOR = "Dan Hetrick"
    VERSION = "1.0"
    SOURCE = "https://github.com/nutjob-laboratories/merk"
    
    def init(self):
        self.macro("ip","ip.merk","/ip","Gets the external IP address")

    def pause(self):
        self.unmacro("ip")

    def unpause(self):
        self.macro("ip","ip.merk","/ip","Gets the external IP address")

    def uninstall(self):
        self.unmacro("ip")
        script = self.find("ip","merk")
        if script!=None: os.remove(script)

    def get_ip(self,window,arguments):
        try:
            with urllib.request.urlopen("https://v4.ident.me") as response:
                external_ip = response.read().decode('utf8')
                window.print(external_ip)
        except urllib.error.URLError as e:
            window.print(f"Error retrieving external IP: {e.reason}")
        except Exception as e:
            window.print(f"An unexpected error occurred: {e}")
