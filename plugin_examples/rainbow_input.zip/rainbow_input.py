from merk import Plugin

import random

class RainbowInput(Plugin):

    NAME = "Rainbow Input"
    AUTHOR = "Dan Hetrick"
    VERSION = "1.0"
    SOURCE = "https://github.com/nutjob-laboratories/merk"

    def input(self,window,user_input):
        output = []
        for word in user_input.split():
            if word.startswith("!"):
                new_word = []
                for letter in word[1:]:
                    if window.is_light():
                        colors = [2,3,6,10,12,14]
                    else:
                        colors = [0,4,7,8,9,11,13,15]
                    new_word.append(f"<{random.choice(colors)}{letter}>")
                word = ''.join(new_word)
            output.append(word)
        return " ".join(output)