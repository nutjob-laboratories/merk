from merk import Plugin
import random,os

class RainbowChat(Plugin):

    NAME = "Rainbow"
    AUTHOR = "Dan Hetrick"
    VERSION = "1.0"
    SOURCE = "https://github.com/nutjob-laboratories/merk"

    def init(self):
        self.macro("rainbow","rainbow.merk","/rainbow TEXT...","Says some rainbow text")
    
    def unload(self):
        self.unmacro("rainbow")
    
    def pause(self):
        self.unmacro("rainbow")
    
    def unpause(self):
        self.macro("rainbow","rainbow.merk","/rainbow TEXT...","Says some rainbow text")

    def uninstall(self):
        self.unmacro("rainbow")
        script = self.find("rainbow","merk")
        if script!=None: os.remove(script)

    def rainbow(self,window,arguments):
        output = []
        if self.darkmode():
            colors = [0,4,7,8,9,11,13,15]
        else:
            colors = [2,3,6,10,12,14]
        msg = ' '.join(arguments)
        for letter in msg:
            output.append(f"<{random.choice(colors)}{letter}>")
        if len(output)>0:
            chat ='**'+''.join(output)+'**'
            window.say(chat)
